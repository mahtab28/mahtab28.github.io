export { default } from './CourseDetails';
