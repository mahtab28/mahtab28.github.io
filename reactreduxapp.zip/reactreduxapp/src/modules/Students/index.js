export { default } from './StudentDetails';
