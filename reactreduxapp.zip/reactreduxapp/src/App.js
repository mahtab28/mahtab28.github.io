import React from 'react';
import Main from './modules/App/'

function App() {
  return (
    <Main />
  );
}

export default App;
